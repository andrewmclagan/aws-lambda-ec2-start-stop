'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.mapRegions = mapRegions;
exports.mapInstances = mapInstances;
exports.discoverAvailableRegions = discoverAvailableRegions;
exports.discoverRegionInstances = discoverRegionInstances;
exports.stopTaggedInstances = stopTaggedInstances;
exports.startTaggedInstances = startTaggedInstances;

var _awsSdk = require('aws-sdk');

var _awsSdk2 = _interopRequireDefault(_awsSdk);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * Returns an array of instances from a regions Reservations
 *
 * @return Promise
 */

function mapRegions(regions) {
	return regions.map(function (region) {
		return region.RegionName;
	});
}

/**
 * Returns an array of instances from a regions Reservations
 *
 * @return Promise
 */

function mapInstances(reservations, status) {
	var instances = [];
	reservations.forEach(function (reservation) {
		return reservation.Instances.forEach(function (instance) {
			if (instance.State.Code === status) {
				instances.push(instance.InstanceId);
			}
		});
	});
	return instances;
}

/**
 * Describes available regions
 *
 * @return Promise
 */

function discoverAvailableRegions() {
	var ec2 = new _awsSdk2.default.EC2();

	return new Promise(function (resolve) {
		return ec2.describeRegions({}, function (error, response) {
			return resolve(mapRegions(response.Regions));
		});
	});
}

/**
 * Describes available instances in a region
 *
 * @return Promise
 */

function discoverRegionInstances(tag, region, status) {
	var ec2 = new _awsSdk2.default.EC2({ region: region });

	var params = {
		Filters: [{ Name: 'tag:' + tag.name, Values: [tag.value] }]
	};

	return new Promise(function (resolve) {
		return ec2.describeInstances(params, function (error, response) {
			return resolve(mapInstances(response.Reservations, status));
		});
	});
}

/**
 * Stops an array of instances
 *
 * @return Promise
 */

function stopTaggedInstances(event, context) {
	var tag = { name: 'stop-group', value: context.functionName };

	return new Promise(function (resolve) {
		discoverAvailableRegions().then(function (regions) {
			return regions.forEach(function (region) {
				return discoverRegionInstances(tag, region, 16).then(function (instances) {
					if (instances.length) {
						new _awsSdk2.default.EC2({ region: region }).stopInstances({ InstanceIds: instances }, function (error, response) {
							resolve(error || response);
						});
					}
				});
			});
		});
	});
}

/**
 * Starts an array of instances
 *
 * @return Promise
 */

function startTaggedInstances(event, context) {
	var tag = { name: 'start-group', value: context.functionName };

	return new Promise(function (resolve) {
		discoverAvailableRegions().then(function (regions) {
			return regions.forEach(function (region) {
				return discoverRegionInstances(tag, region, 80).then(function (instances) {
					if (instances.length) {
						new _awsSdk2.default.EC2({ region: region }).startInstances({ InstanceIds: instances }, function (error, response) {
							resolve(error || response);
						});
					}
				});
			});
		});
	});
}